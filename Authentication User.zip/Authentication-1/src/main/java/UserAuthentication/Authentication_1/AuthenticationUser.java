package UserAuthentication.Authentication_1;

public class AuthenticationUser {
	public String username()
	{
		String email = "abi@gmail.com";
		return email;
	}
	
	public String paswd()
	{
		String password = "myPassword@28";
		return password;
	}

}
