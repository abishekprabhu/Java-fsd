import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { SigninComponent } from './homepage/signin/signin.component';
import { SignupComponent } from './homepage/signup/signup.component';
import { DashboardComponent } from './homepage/dashboard/dashboard.component';
import { EmployeeListComponent } from './homepage/dashboard/employee-list/employee-list.component';
import { ViewDetailsComponent } from './homepage/dashboard/view-details/view-details.component';
import { AddEmployeeComponent } from './homepage/dashboard/add-employee/add-employee.component';
import { UpdateComponent } from './homepage/dashboard/update/update.component';

const routes: Routes = [ {path:"",redirectTo:"homepage",pathMatch:"full"},
{path:'homepage',
component:HomepageComponent},
{path:'signin',
component:SigninComponent},
{path:'signup',
component:SignupComponent},
{path:'home',
component:DashboardComponent},
{path:'employeelist',
component:EmployeeListComponent},
{path:'viewdetails/:id',
component:ViewDetailsComponent},
{path:'addEmployee',
component:AddEmployeeComponent},

{ path: 'update/:id',
 component: UpdateComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
