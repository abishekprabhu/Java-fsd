import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SigninComponent } from './homepage/signin/signin.component';
import { SignupComponent } from './homepage/signup/signup.component';
import {ReactiveFormsModule} from '@angular/forms';
import { DashboardComponent } from './homepage/dashboard/dashboard.component';
import { EmployeeListComponent } from './homepage/dashboard/employee-list/employee-list.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewDetailsComponent } from './homepage/dashboard/view-details/view-details.component';
import { AddEmployeeComponent } from './homepage/dashboard/add-employee/add-employee.component';
import { UpdateComponent } from './homepage/dashboard/update/update.component';


@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    SignupComponent,
    SigninComponent,
    DashboardComponent,
    EmployeeListComponent,
    ViewDetailsComponent,
    AddEmployeeComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
