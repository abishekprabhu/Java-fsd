import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  public getEmployees() {
    return this.http.get("http://localhost:3000/employees");
  }
  
  public getEmployeeById(id:any) {
    return this.http.get("http://localhost:3000/employees/"+id);
  }

   public deletebyid(id:any ) {
    return this.http.delete("http://localhost:3000/employees/"+id);
  }
  
  public putEmployee(id:any,EmployeeData: any) {
    return this.http.put("http://localhost:3000/employees/"+id, EmployeeData);
  }
  
  public postEmployee(EmployeeData: any) {
    return this.http.post("http://localhost:3000/employees", EmployeeData);
  }



}
