import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employees: any;

  constructor(
    private service: EmployeeService,
    private builder: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {}

  result: any;
  msg: string = '';

  regForm = this.builder.group({
    first_name: this.builder.control('', Validators.required),
    last_name: this.builder.control('', Validators.required),
    email: this.builder.control('', Validators.required)
  });

  printDetails() {
    if (this.regForm.valid) {
      const EmployeeData = {
        first_name: this.regForm.value.first_name,
        last_name: this.regForm.value.last_name,
        email: this.regForm.value.email
      };

      this.service.postEmployee(EmployeeData).subscribe(
        (response) => {
          console.log(response);
        },
        (error) => {
          console.error(error);
        }
      );

      this.msg = 'Employee Details Added successfully...! ' + JSON.stringify(EmployeeData);
      setTimeout(() => {
        this.router.navigate(['/employeelist']);
      }, 700); // Wait for 0.7 seconds before redirecting
    } else {
      this.msg = 'Invalid Form';
    }
  }
}
