import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  loggedInUser: any;
  showResetForm: boolean = false;
  newPassword: string = '';
  employees:any;
  message='';
  id:any;
  constructor(private service:EmployeeService) { }

  ngOnInit(): void {
    const storedUser = localStorage.getItem('loggedInUser');
    if (storedUser) {
      this.loggedInUser = JSON.parse(storedUser);
    }
    


  }

  findById(id: number) {
    if (id) {
      let response = this.service.getEmployeeById(id);
      response.subscribe((data: any) => {
        this.employees = [data];
      });
    } else {
      let response = this.service.getEmployees();
      response.subscribe((data: any) => {
        this.employees = data;
      });
    }
  }

  resetPassword() {
    // Update the password for the logged-in user
    this.loggedInUser.password = this.newPassword;

    // Store the updated user data in localStorage
    localStorage.setItem('loggedInUser', JSON.stringify(this.loggedInUser));

    // Reset the form and hide it
    this.newPassword = '';
    this.showResetForm = false;

    // Set the message to be displayed
    this.message = 'Password has been updated successfully.';
    // You can change the message as needed
    // For other updates, you can set a different message here
  }
}
