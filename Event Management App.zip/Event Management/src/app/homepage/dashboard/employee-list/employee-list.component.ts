import { Component,OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit{
  employees:any;
  message='';
  id:any;

  
  constructor(private service:EmployeeService) { }
  ngOnInit(): void {
    let response=this.service.getEmployees();
    response.subscribe((data:any)=>this.employees=data);
  }


  findById(id: number) {
    if (id) {
      let response = this.service.getEmployeeById(id);
      response.subscribe((data: any) => {
        this.employees = [data];
      });
    } else {
      let response = this.service.getEmployees();
      response.subscribe((data: any) => {
        this.employees = data;
      });
    }
  }
  



}
