import { ActivatedRoute } from '@angular/router';
import { Component,OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  employees:any;

  message = '';
    constructor(private route: ActivatedRoute,private service:EmployeeService) { }
  
  
    ngOnInit(): void {
      const id = this.route.snapshot.paramMap.get('id');
      let response=this.service.getEmployeeById(id);
      response.subscribe((data:any)=>this.employees=data);
    }
    updateNow(id: number) {
      let response = this.service.putEmployee(id, this.employees);
      response.subscribe((data: any) => {
        this.message = "Updated...!  id: "+id;
      });
    }
  }