import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {
  employees: any;
  message = '';

  constructor(
    private route: ActivatedRoute,
    private service: EmployeeService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    let response = this.service.getEmployeeById(id);
    response.subscribe((data: any) => {
      this.employees = data;
      this.cdr.detectChanges(); // Detect changes after updating the employees data
    });
  }
// update
  updateNow(id: number) {
    let response = this.service.putEmployee(id, this.employees);
    response.subscribe((data: any) => {
      this.message = 'Updated...!  id: ' + id;
    });
  }
// delte with changedetect function
  deleteEmployee(id: number) {
    let response = this.service.deletebyid(id);
    response.subscribe((data: any) => {
      this.employees = data;
      this.message = 'Deleted it...!  id: ' + id;
      this.cdr.detectChanges(); // Detect changes after updating the employees data      
      setTimeout(() => {
        this.router.navigate(['/employeelist']);
      }, 1000); // Wait for 1 seconds before redirecting
    });
  }
}
