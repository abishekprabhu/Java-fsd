import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  username: string = "";
  password: string = "";
  msg: string = "";

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
//get the data from the localstorage to check the validation
  LoginCheck(frm: any) {
    if (frm.valid) {
      const storedData = localStorage.getItem('registrationData');

      if (storedData) {
        const registrationData = JSON.parse(storedData);

        if (this.username === registrationData.email && this.password === registrationData.password) {
          // Login successful
          localStorage.setItem('loggedInUser', JSON.stringify(registrationData));
          this.msg = "Login Successfully";
          setTimeout(() => {
            this.router.navigate(['/home']);
          }, 500); //wait for 0.5sec to redirect to home
        } else {
          this.msg = "Incorrect..!<br />Please check your email and password";
        }
      } else {
        this.msg = "No registration data found";
      }
    } else {
      this.msg = "Invalid Form";
    }
  }

}
