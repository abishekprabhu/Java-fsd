import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private builder: FormBuilder,private router: Router) { }

  ngOnInit(): void {
  }

  result: any;
  msg: string = "";

  regForm = this.builder.group({
    personname: this.builder.control('', Validators.required),
    phonenumber: this.builder.control('', Validators.required),
    email: this.builder.control('', [Validators.required, Validators.email]),
    password: this.builder.control('', Validators.required)
  });

  printDetails() {
    if (this.regForm.valid) {
      const registrationData = {
        personname: this.regForm.value.personname,
        phonenumber: this.regForm.value.phonenumber,
        email: this.regForm.value.email,
        password: this.regForm.value.password
      };
    // check the email is already exists...!
      const storedData = localStorage.getItem('registrationData');
    
      if (storedData) {
        const existingData = JSON.parse(storedData);
        if (existingData.email === registrationData.email) {
          this.msg = "Email already exists. Please choose a different email.";
          return;
        }
      }
      // if email is not exist store the data 
      localStorage.setItem('registrationData', JSON.stringify(registrationData));

      this.msg = "Registration successful....!" ;
      setTimeout(() => {
        this.router.navigate(['/signin']);
      }, 700); // Wait for 0.7 seconds before redirecting

    } else {
      this.msg = "Invalid Form";
    }
  }
}
