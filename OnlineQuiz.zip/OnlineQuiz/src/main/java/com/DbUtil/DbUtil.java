package com.DbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class DbUtil {
	StandardServiceRegistry  ssr=null;
	Metadata md=null;
	SessionFactory sf=null;
	Session session=null;

	
	public Session dbConn() {
		
		ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		md = new MetadataSources(ssr).getMetadataBuilder().build();
		sf = md.getSessionFactoryBuilder().build();
		session = sf.openSession();
		
		return session;
	}
	
		
		private static final String DRIVER_CLASS="com.mysql.jdbc.Driver";
		
		private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/db1";
		
		private static final String USERNAME = "root";
		private static final String PASSWORD = "Hrithigavarshini@28";
		
	    public static Connection getConn() throws ClassNotFoundException, SQLException {
			
	    	Class.forName(DRIVER_CLASS);
	    	
	    	Connection con = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
	    	return con;

		}


}
