package com.LeaderboardPOJO;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "leaderboard")
public class Leaderboard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "category")
    private String category;

    @Column(name = "quiz_title")
    private String quizTitle;

    @Column(name = "score")
    private int score;

    // Constructors, getters, and setters

    public Leaderboard() {
    }

    public Leaderboard(String userId, String category, String quizTitle, int score) {
        this.userId = userId;
        this.category = category;
        this.quizTitle = quizTitle;
        this.score = score;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getQuizTitle() {
        return quizTitle;
    }

    public void setQuizTitle(String quizTitle) {
        this.quizTitle = quizTitle;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

	@Override
	public String toString() {
		return "Leaderboard [id=" + id + ", userId=" + userId + ", category=" + category + ", quizTitle=" + quizTitle
				+ ", score=" + score + "]";
	}
    
    
}
