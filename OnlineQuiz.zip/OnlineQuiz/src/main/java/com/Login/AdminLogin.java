package com.Login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.DbUtil.DbUtil;
import com.Register.Admin;
import com.Register.Register;

/**
 * Servlet implementation class AdminLogin
 */
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
//		String name = request.getParameter("name");
		PrintWriter out = response.getWriter();
		if (email == null || email.isEmpty() && password.isEmpty()) {
			  response.setContentType("text/html");
	            RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
	            rd.include(request, response);
	            out.println("<footer align='center'><b>Your session has expired or is invalid.</b><br></footer>");
	         } else {
	       
	        
			DbUtil dbconn=new DbUtil();
			Session session=dbconn.dbConn();
			Transaction trans=session.beginTransaction();
			Query<Admin> querry=session.createQuery("SELECT r FROM Admin r WHERE r.email = :email AND r.password = :password", Admin.class);
            querry.setParameter("email",email);
            querry.setParameter("password",password);
			Admin admin= querry.uniqueResult();
			
			
			if (admin!=null) {
				    String name = admin.getName();
					HttpSession httpsession = request.getSession();
					httpsession.setAttribute("userid",name);
					response.sendRedirect("dashboard.jsp");				
					}	
			else 
			{
				response.sendRedirect("admin.jsp");
			}
			trans.commit();
			session.close();		
            
	}
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}