package com.Question;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Servlet implementation class AddQuestionServlet
 */
public class AddQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String category = request.getParameter("category");
	        String quizTitle = request.getParameter("quizTitle");
	        String question = request.getParameter("question");
	        String option1 = request.getParameter("option1");
	        String option2 = request.getParameter("option2");
	        String option3 = request.getParameter("option3");
	        String option4 = request.getParameter("option4");
	        String answer = request.getParameter("answer");

	        // Save the question to the respective quiz table
	        String dbName = category.equals("science") ? "science_quiz_db" : "maths_quiz_db";
	        String insertQuestionQuery = "INSERT INTO " + dbName + "." + quizTitle +
	                " (question, option1, option2, option3, option4, answer) " +
	                "VALUES ('" + question + "', '" + option1 + "', '" + option2 + "', '" +
	                option3 + "', '" + option4 + "', '" + answer + "')";

	        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
	        Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
	        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
	        Session session = sessionFactory.openSession();
	        Transaction transaction = session.beginTransaction();
	        session.createSQLQuery(insertQuestionQuery).executeUpdate();
	        transaction.commit();
	        session.close();

	        response.sendRedirect("createQuestion.jsp?category=" + category + "&quizTitle=" + quizTitle);	}
	        

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
