package com.Question;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.DbUtil.DbUtil;
import com.Register.Register;

/**
 * Servlet implementation class AddUserServlet
 */
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("user");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		Date dob = null;
		try {
			dob = dateFormat.parse(request.getParameter("dob"));
		} catch (ParseException e) {

			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if (email == null || email.isEmpty() && password.isEmpty()) {
            out.println("Not Register");
        } else {
	        Register register = new Register();
	        register.setUser(user);
	        register.setEmail(email);
	        register.setPassword(password);
	        register.setDob(dob);
			DbUtil dbconn=new DbUtil();
			Session session=dbconn.dbConn();
			Transaction trans=session.beginTransaction();
			session.saveOrUpdate(register);
			
			trans.commit();
			session.close();
			
		
            response.sendRedirect("dashboard.jsp");

        }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
