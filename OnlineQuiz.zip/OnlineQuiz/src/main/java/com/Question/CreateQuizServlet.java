package com.Question;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Servlet implementation class CreateQuizServlet
 */
public class CreateQuizServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateQuizServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String category = request.getParameter("category");
        String quizTitle = request.getParameter("quizTitle");

        // Create a separate database for each category
        String dbName = category.equals("science") ? "science_quiz_db" : "maths_quiz_db";
        String createDbQuery = "CREATE DATABASE IF NOT EXISTS " + dbName;

        // Execute the database creation query
        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
        Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.createSQLQuery(createDbQuery).executeUpdate();
        transaction.commit();

        // Create the quiz table
        String createTableQuery = "CREATE TABLE IF NOT EXISTS " + dbName + "." + quizTitle + " (question_no INT PRIMARY KEY AUTO_INCREMENT, " +
                "question VARCHAR(255) NOT NULL, option1 VARCHAR(255), option2 VARCHAR(255), option3 VARCHAR(255), " +
                "option4 VARCHAR(255), answer VARCHAR(255))";

        transaction = session.beginTransaction();
        session.createSQLQuery(createTableQuery).executeUpdate();
        transaction.commit();

        session.close();

        response.sendRedirect("createQuestion.jsp?category=" + category + "&quizTitle=" + quizTitle);	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
