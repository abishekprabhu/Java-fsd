package com.Question;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.DbUtil.DbUtil;

/**
 * Servlet implementation class EditQuestionServlet
 */
public class EditQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String question_no = request.getParameter("question_no");
		String Question = request.getParameter("Question");
		String option1 = request.getParameter("option1");
		String option2 = request.getParameter("option2");
		String option3 = request.getParameter("option3");
		String option4 = request.getParameter("option4");
		String answer = request.getParameter("answer");

		
		  PrintWriter out = response.getWriter(); 
		  
		  if (Question == null && option1 == null && option2 == null && option3 == null && option4 == null && answer ==null) 
		  { out.println("FILL EVERYTHING");
		     }
		  else {

			
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
	    Transaction trans = session.beginTransaction();
		 

		Question question = new Question();
		question.setQuestion(Question);
		question.setOption1(option1);
		question.setOption2(option2);
		question.setOption3(option3);
		question.setOption4(option4);
		question.setAnswer(answer);
		
		Query<Question> query=session.createQuery("update Question set Question=:Question , option1=:option1 , option2=:option2 , option3=:option3, option4=:option4 , answer=:answer where question_no=:question_no");
		query.setParameter("Question",question.getQuestion());
		query.setParameter("option1",question.getOption1());
		query.setParameter("option2",question.getOption2());
		query.setParameter("option3", question.getOption3());
		query.setParameter("option4", question.getOption4());
		query.setParameter("answer", question.getAnswer());
		query.setParameter("question_no", Integer.parseInt(question_no));		
		int update =query.executeUpdate();

		
        if(update>0) {
        	response.sendRedirect("questionList.jsp");
        }
        else {
        	response.sendRedirect("editQuestion.jsp");
        }
		session.close();
		
		  }
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
