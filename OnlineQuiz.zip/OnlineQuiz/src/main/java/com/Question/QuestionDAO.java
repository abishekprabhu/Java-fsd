package com.Question;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.DbUtil.DbUtil;




public class QuestionDAO {
	public List<Question> display(){
		DbUtil dbconn=new DbUtil();
		Session session=dbconn.dbConn();
		Transaction trans=session.beginTransaction();
		//HQL
		Query query=session.createQuery("from Question");
		List<Question> list=query.list();
		trans.commit();
		session.close();
		return list;
	}
	
	public List<Question> delete(Question question) {
		DbUtil dbconn=new DbUtil();
		Session session=dbconn.dbConn();
		Transaction trans=session.beginTransaction();
		session.delete(question);
		trans.commit();
		session.close();
		return display();
	}
	
}
