package com.Question;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Servlet implementation class UpdateQuestionServlet
 */
public class UpdateQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    String category = request.getParameter("category");
	    String quizTitle = request.getParameter("quizTitle");
		int question_no = Integer.parseInt(request.getParameter("question_no"));
        String questionText = request.getParameter("Question");
        String option1 = request.getParameter("option1");
        String option2 = request.getParameter("option2");
        String option3 = request.getParameter("option3");
        String option4 = request.getParameter("option4");
        String answer = request.getParameter("answer");
        String dbName = category.equals("science") ? "science_quiz_db" : "maths_quiz_db";
        

        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
        Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        String updateQuery = "UPDATE " + dbName + "." + quizTitle + " SET Question = :question, " +
                "option1 = :option1, option2 = :option2, option3 = :option3, option4 = :option4, " +
                "answer = :answer WHERE question_no = :question_no";

        int rowsUpdated = session.createSQLQuery(updateQuery)
                .setParameter("question", questionText)
                .setParameter("option1", option1)
                .setParameter("option2", option2)
                .setParameter("option3", option3)
                .setParameter("option4", option4)
                .setParameter("answer", answer)
                .setParameter("question_no", question_no)
                .executeUpdate();

        transaction.commit();
        session.close();

        response.sendRedirect("viewQuestion.jsp?category=" + category + "&quizTitle=" + quizTitle);

	
	}

}
