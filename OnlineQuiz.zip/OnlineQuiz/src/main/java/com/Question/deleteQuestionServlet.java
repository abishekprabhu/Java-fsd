package com.Question;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Servlet implementation class deleteQuestionServlet
 */
public class deleteQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 int question_no = Integer.parseInt(request.getParameter("question_no"));
		    String category = request.getParameter("category");
	        String dbName = category.equals("science") ? "science_quiz_db" : "maths_quiz_db";
		    String quizTitle = request.getParameter("quizTitle");


	        StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
	        Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
	        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
	        Session session = sessionFactory.openSession();
	        Transaction transaction = session.beginTransaction();

	        String deleteQuery = "DELETE FROM " + dbName + "." + quizTitle + " WHERE question_no = :question_no";

	        int rowsDeleted = session.createSQLQuery(deleteQuery)
	                .setParameter("question_no", question_no)
	                .executeUpdate();
            if(rowsDeleted>0) {
	        transaction.commit();
	        session.close();

	        response.sendRedirect("viewQuestion.jsp?category=" + category + "&quizTitle=" + quizTitle);
            }else {
            	response.sendRedirect("viewQuestion.jsp?category=" + category + "&quizTitle=" + quizTitle);
            }
	}

}
