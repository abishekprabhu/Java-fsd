package com.Register;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Register {
	
private String user;
@Id
private String email;
private String password;
@Temporal(TemporalType.DATE)
private Date dob;

public Register() {
	
}


public Register(String user, String email, String password, Date dob) {
	super();
	this.user = user;
	this.email = email;
	this.password = password;
	this.dob = dob;
}


public Date getDob() {
	return dob;
}


public void setDob(Date dob) {
	this.dob = dob;
}


public String getUser() {
	return user;
}
public void setUser(String user) {
	this.user = user;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "Register [user=" + user + ", email=" + email + ", password=" + password + ", Dob=" + dob + "]";
}


}
