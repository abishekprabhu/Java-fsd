package com.Register;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.DbUtil.DbUtil;


public class RegisterDAO {
	public List<Register> display(){
		DbUtil dbconn=new DbUtil();
		Session session=dbconn.dbConn();
		Transaction trans=session.beginTransaction();
		//HQL
		Query query=session.createQuery("from Register");
		List<Register> list=query.list();
		trans.commit();
		session.close();
		return list;
	}
	public List<Register> delete(Register register) {
		DbUtil dbconn=new DbUtil();
		Session session=dbconn.dbConn();
		Transaction trans=session.beginTransaction();
		session.delete(register);
		trans.commit();
		session.close();
		return display();
	}
	
}
