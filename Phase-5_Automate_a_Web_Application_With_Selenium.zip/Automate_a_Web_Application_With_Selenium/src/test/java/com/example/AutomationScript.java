package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutomationScript {
    public static void main(String[] args) throws InterruptedException {
        // Set up WebDriver
    	WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();

        // Registration
        driver.get("http://127.0.0.1:5501/register.html");
        System.out.println("Register Page");

        WebElement nameField = driver.findElement(By.id("name"));
        nameField.sendKeys("John Doe");

        WebElement UserNameField = driver.findElement(By.id("username"));
        UserNameField.sendKeys("john.doe@example.com");

        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("password123");

        WebElement signupButton = driver.findElement(By.xpath("//button[text()='Register']"));
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(signupButton));

        // Click the button
        signupButton.click();

        System.out.println("Registration Successful!");
        Thread.sleep(4000);

        // Login
        driver.get("http://127.0.0.1:5501/login.html");
        System.out.println("Login Page");

        WebElement emailFieldLogin = driver.findElement(By.id("loginUsername"));
        emailFieldLogin.sendKeys("john.doe@example.com");

        WebElement passwordFieldLogin = driver.findElement(By.id("loginPassword"));
        passwordFieldLogin.sendKeys("password123");

        WebElement loginButton = driver.findElement(By.xpath("//button[text()='Login']"));
        WebDriverWait wait1 = new WebDriverWait(driver, 10);
        wait1.until(ExpectedConditions.elementToBeClickable(loginButton));

        // Click the button
        Thread.sleep(3000); // Add some delay to simulate login click process
        loginButton.click();

        System.out.println("Logging in...");
        Thread.sleep(5000); // Add some delay to simulate login process

        System.out.println("Login Successful!");
        Thread.sleep(2000); // Add some delay before closing the browser

        // Close the WebDriver
        driver.quit();
    }
}
