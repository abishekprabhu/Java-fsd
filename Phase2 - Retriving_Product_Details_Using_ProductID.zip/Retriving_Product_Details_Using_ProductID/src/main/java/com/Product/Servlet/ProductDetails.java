package com.Product.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Product.dbUtil.DBConnection;

/**
 * Servlet implementation class ProductDetails
 */
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            
		PrintWriter out = response.getWriter();
	        try {
	        	//jdbc connection
				Connection con = DBConnection.getConnection();
				
				String id = request.getParameter("id");
				//sql statement
				String querry = "select * from product where id=?";
				PreparedStatement stmt = con.prepareStatement(querry);
				stmt.setString(1, id);
				ResultSet rs = stmt.executeQuery();
				//retriving data
				if(rs.next()) {
					out.println("<h2>Product Details:</h2>");
					out.println("<p><b>Product ID:</b> " + rs.getInt("ID") + "</p>");
					out.println("<p><b>Product Name:</b> " + rs.getString("name") + "</p>");
					out.println("<p><b>Product Price:</b> $ "+rs.getBigDecimal("price") + "</p>");
				}else {
					out.println("<h2> Product not found! </h2>");
				}
				
				rs.close();
				stmt.close();
				con.close();
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
