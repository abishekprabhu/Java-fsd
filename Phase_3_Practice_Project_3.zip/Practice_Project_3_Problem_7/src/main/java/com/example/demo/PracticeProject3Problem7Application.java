package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject3Problem7Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject3Problem7Application.class, args);
	}

}
