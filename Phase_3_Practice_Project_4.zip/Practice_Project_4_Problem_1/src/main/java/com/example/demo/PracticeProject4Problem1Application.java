package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeProject4Problem1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeProject4Problem1Application.class, args);
	}

}
