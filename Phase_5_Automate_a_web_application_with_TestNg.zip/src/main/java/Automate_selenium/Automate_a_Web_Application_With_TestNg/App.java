package Automate_selenium.Automate_a_Web_Application_With_TestNg;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
