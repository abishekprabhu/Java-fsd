package com.example;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestAutomation {
    private WebDriver driver;
    private Workbook workbook;
    private Sheet sheet;
    private int rowNumber;

    @BeforeTest
    public void setUp() {
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Test(priority = 1)
    public void testRegistration() throws InterruptedException, IOException {
        driver.get("http://127.0.0.1:5501/register.html");

        WebElement nameField = driver.findElement(By.id("name"));
        nameField.sendKeys("John Doe");

        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.sendKeys("john.doe@example.com");

        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("password123");
//        Thread.sleep(2000);
        WebElement registerButton = driver.findElement(By.xpath("//button[text()='Register']"));
        registerButton.click();
        Thread.sleep(2000);
        
        //takescreenshot
     //   takeScreenshot(driver,"Registeration");
        // Wait for registration success message (you can add some delays here if needed)
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("registrationMessage")));

        // Assert the success message content
        Assert.assertEquals(successMessage.getText(), "Registration successful! Please login.");

//        Thread.sleep(000);
    }

    @Test(priority = 2)
    public void testLoginSuccess() throws InterruptedException, IOException {
        driver.get("http://127.0.0.1:5501/login.html");

        // Login form elements
        WebElement emailFieldLogin = driver.findElement(By.id("loginUsername"));
        WebElement passwordFieldLogin = driver.findElement(By.id("loginPassword"));
        WebElement loginButton = driver.findElement(By.xpath("//button[text()='Login']"));

        // Enter valid login credentials
        emailFieldLogin.sendKeys("john.doe@example.com");
        passwordFieldLogin.sendKeys("password123");

        // Click the login button
        loginButton.click();
        //takescreenshot
      //  takeScreenshot(driver,"LoginSuccess");
        Thread.sleep(1000);
        
        // Wait for the success message (you can add some delays here if needed)
        WebElement successMessage = driver.findElement(By.id("errorMsg"));
        Assert.assertEquals(successMessage.getText(), "Login successfully....!");
    }

    @Test(priority = 3)
    public void testLoginFailure() throws IOException {
        driver.get("http://127.0.0.1:5501/login.html");

        // Login form elements
        WebElement emailFieldLogin = driver.findElement(By.id("loginUsername"));
        WebElement passwordFieldLogin = driver.findElement(By.id("loginPassword"));
        WebElement loginButton = driver.findElement(By.xpath("//button[text()='Login']"));

        // Enter invalid login credentials
        emailFieldLogin.sendKeys("invalid@example.com");
        passwordFieldLogin.sendKeys("invalidpassword");

        // Click the login button
        loginButton.click();
        
       // takeScreenshot(driver,"LoginFailure");
        
        // Wait for the error message (you can add some delays here if needed)
//        WebElement successMessage = driver.findElement(By.id("errorMsg"));
//        Assert.assertEquals(successMessage.getText(), "Login successfully....!");
        WebElement errorMessage = driver.findElement(By.id("errorMsg"));
        Assert.assertEquals(errorMessage.getText(), "Invalid credentials. Please try again.");
    }
    
    
    
    

    
    @Test(priority = 4) 
	  public void amazonSearch() throws IOException {
  	  driver.get("https://www.google.com");
  	  driver.findElement(By.name("q")).sendKeys("amazon");
  	  driver.findElement(By.name("q")).submit();
  	
  	  // Wait for the Amazon link to appear and click on it
  	  driver.findElement(By.partialLinkText("Amazon")).click();
  	
  	  // Search for "samsung" on Amazon
  	  driver.findElement(By.name("field-keywords")).sendKeys("samsung");
  	  driver.findElement(By.name("field-keywords")).sendKeys(Keys.ENTER);
  	  
  	 // takeScreenshot(driver,"AmazonSearch");
  	  
//  	  driver.findElement(By.xpath("//*[@id=\'search\']/div[1]/div[1]/div/span[1]/div[1]/div[7]/div/div/div/div/div[3]/div[1]/h2/a\n"
//  	  		)).click();
  	  // Add some delay to observe the search result
  	  try {
  	      Thread.sleep(2000);
  	  } catch (InterruptedException e) {
  	      e.printStackTrace();
  	  }
  }
    
    //addToCart
    @Test(priority = 5) 
    public void addToCart() throws InterruptedException, IOException {
        driver.get("https://www.amazon.com");

        // Search for "cricket bat" on Amazon
        driver.findElement(By.name("field-keywords")).sendKeys("cricket bat");
        driver.findElement(By.name("field-keywords")).sendKeys(Keys.ENTER);

        // Wait for the search results to appear
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("span.a-size-medium.a-color-base.a-text-normal"))).click();

        // Scroll to the "Add to Cart" button
        WebElement addToCartButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("add-to-cart-button")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addToCartButton);

        // Wait for the element to be clickable and click it
        wait.until(ExpectedConditions.elementToBeClickable(addToCartButton)).click();
        
        driver.findElement(By.xpath("//*[@id=\'sw-gtc\']/span/a")).click();
        
      //  takeScreenshot(driver,"addToCart");
        // Add some delay to observe the search result
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    
    //takescreenshots
public static void takeScreenshot(WebDriver wd,String fileName) throws IOException {
	//take the screenshot and store it as a file format
	File file=((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
	//now copy the screen shot to the specified location 
	FileUtils.copyFile(file,new File("B:\\Phase-3-Spring\\Automate_a_Web_Application_With_TestNg\\"+fileName+".png"));
}


    @AfterMethod
    public void afterMethod(ITestResult result) {
        // Capture test results and write to the Excel file
        String testName = result.getMethod().getMethodName();
        String status = result.isSuccess() ? "Passed" : "Failed";

        Row row = sheet.createRow(rowNumber++);
        row.createCell(0).setCellValue(testName);
        row.createCell(1).setCellValue(status);
    }

    @AfterTest
    public void tearDown() throws IOException {
        // Save the test results to an Excel file
        FileOutputStream fileOut = new FileOutputStream("TestResults.xlsx");
        workbook.write(fileOut);
        fileOut.close();

        driver.quit();
    }

    @BeforeSuite
    public void beforeSuite() {
        // Create an Excel workbook and sheet to store test results
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Test Results");
        rowNumber = 0;

        // Create the header row
        Row headerRow = sheet.createRow(rowNumber++);
        headerRow.createCell(0).setCellValue("Test Name");
        headerRow.createCell(1).setCellValue("Status");
    }

    @AfterSuite
    public void afterSuite() {
        // Close the workbook
        try {
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
