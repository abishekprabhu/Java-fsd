package Problem_1;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		
		
		int arr[] = new int[] {10,20,30,40,50};
		Scanner in = new Scanner (System.in);
		
		System.out.print("Enter the Number to search: ");
		int key = in.nextInt();
		
		int result = linearing(arr,key);
		
		if(result == -1) {
			System.out.println("Element not in an array");
		}else {
			System.out.println("Element Found in the index of "+result);
		}
        
	}

	private static int linearing(int[] arr, int key) {
		
			
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==key)
				return i;
		}
		return -1;
	}

}
