package Problem_3;

import java.util.Arrays;

public class ExponentialSearch {
    public static void main(String[] args) {
		int arr[] = {6,12,18,24,32};
		int key = 18;
		
		int result = exponentialSearch(arr,key,arr.length);
	
        if(result<0) {
        	System.out.println("Element is not present in the array");
        }
        else {
        	System.out.println("Element '"+key+"' is found in the array of index: "+result);
        }
    }
    
    

	private static int exponentialSearch(int[] arr, int key, int length) {
		if(arr[0]== key) {
			return 0;
		}
		int i=1;
		while(i<length && arr[i]<=key) {
			i = i*2;
			
		}
		return Arrays.binarySearch(arr,i/2,Math.min(i, length),key) ;
	}
}
