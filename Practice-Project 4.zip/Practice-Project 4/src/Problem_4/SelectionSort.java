package Problem_4;

public class SelectionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		int arr[] = {9,6,3,1,2,4,5};
		int length = arr.length;
		
		System.out.println("Given array:\n");
		for(int i : arr) {
			System.out.print(i +" ");
		}
		System.out.println("\n");
		System.out.println("SelectionSort array:\n");
		selectionSort(arr);
	    for(int i:arr){

	        System.out.print(i+ " ");
	         }

	}

	private static void selectionSort(int[] arr) {
		int min;
		for(int i=0; i<arr.length-1;i++) {
			min= i;
			
			for(int j=i+1;j<arr.length;j++) {
				if(arr[j]<arr[min]) {
					min = j;
				}
			}	
			
			//swap
			int temp = arr[min];
			arr[min] =arr[i];
			arr[i] = temp;
		}		
	}

}