package Problem_5;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {25,20,15,5,10};
		
		System.out.println("Given array:\n");
		for(int i : arr) {
			System.out.print(i +" ");
		}
		System.out.println("\n");
		System.out.println("BubbleSort array:\n");
		bubbleSort(arr);
		for(int i : arr) {
			System.out.print(i+" ");
		}
			
  
	}

	private static void bubbleSort(int[] arr) {
		int length = arr.length;
		int temp =0;
		for(int i=0;i<length;i++) {
			for(int j=1;j<length;j++) {
				if(arr[j-1]>arr[j]) {
					temp = arr[j-1];
					arr[j-1] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
	}

}
