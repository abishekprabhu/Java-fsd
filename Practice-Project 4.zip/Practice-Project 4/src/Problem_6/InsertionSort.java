package Problem_6;

public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {9,12,3,21,44};
		
		System.out.println("Given array:\n");
		for(int i : arr) {
			System.out.print(i +" ");
		}
		System.out.println("\n");
		System.out.println("InsertionSort array:\n");
		
		insertionSort(arr);
		for(int i : arr) {
			System.out.print(i+" ");
		}

	}

	private static void insertionSort(int[] arr) {
		int length = arr.length;
		for(int j=1;j<length;j++) {
			int key = arr[j];
			int i = j-1;
			while((i>-1 )&&(arr[i]>key)) {
				arr[i+1] = arr[i];
				i--;
			}
			arr[i+1] = key;
		}
		
	}

}
