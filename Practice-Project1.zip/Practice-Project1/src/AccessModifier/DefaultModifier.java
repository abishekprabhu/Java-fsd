package AccessModifier;

//Default access modifier - Within package
class modifier{
	//display default method
	void display(){
		System.out.println("Default Access Modifier Method");
	}
}
public class DefaultModifier {
  public static void main(String[] args) {
	modifier obj = new modifier();
	obj.display();
}
}
