package AccessModifier;

public class PrivateAccessModifier {
	    private String str="Private Variable.";
	    private void display() {
        	System.out.println("Private Access Modifier Method.");
        }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        PrivateAccessModifier obj = new PrivateAccessModifier();
        System.out.println(obj.str);
        obj.display();               
	}

}
