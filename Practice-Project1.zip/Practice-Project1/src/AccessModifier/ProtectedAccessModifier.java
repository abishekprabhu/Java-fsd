package AccessModifier;

import AccessModifier1.*;

public class ProtectedAccessModifier extends Protected{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedAccessModifier obj = new ProtectedAccessModifier();
		obj.display();		
	} 

}
