package AccessModifier;

import AccessModifier1.*;

public class PublicAccessModifier extends Public{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        PublicAccessModifier obj = new PublicAccessModifier();
        obj.display();
	}

}
