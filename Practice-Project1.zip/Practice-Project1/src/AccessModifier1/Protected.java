package AccessModifier1;

public class Protected {
	
	protected void display() {
	   	 System.out.println("Protected Access Modifier Method");
	}
}
