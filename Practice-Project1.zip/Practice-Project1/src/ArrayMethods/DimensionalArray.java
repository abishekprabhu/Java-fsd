package ArrayMethods;

public class DimensionalArray {

	public static void main(String[] args) {
		// Single Dimensional Array
		
		//ceating array
		
		System.out.println("Single Dimensional Array");
		int[] a = {10,20,30,40,50};
		for(int i=0;i<a.length;i++) {
			System.out.println("Elements of array a:"+a[i]);
		}
		
		//multidimensional Array
		System.out.println("\nMultiDimensional Array");
		int[][] b = {{2,3,4},{5,6,7},{7,8,9}};
		
		for(int i=0; i<3;i++) {
			for(int j=0;j<3;j++) {
				
			System.out.print(b[i][j]+ " ");
			}
			System.out.println();
		}
		
	}

}
