package Collection;
import java.util.*;
public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList
		System.out.println("ArrayList");
		List<String>  city = new ArrayList<String>();
		//add elements
		city.add("Chennai");
		city.add("Mumbai");
		city.add("Pune");
		System.out.println(city);
		
		//Creating an empty Vector
		System.out.println("\nVector");
		Vector <Integer> x = new Vector<>();
		
		x.addElement(90);
		x.addElement(56);
		System.out.println(x);
		
		//Creating LinkedList
		
	   System.out.println("\nLinkedList");
	   LinkedList<String> li = new LinkedList<>();
	   li.add("Alex");
	   li.add("John");
	   Iterator<String> i = li.iterator();
	   while(i.hasNext()) {
		   System.out.println(i.next());
	   }
	   
	   System.out.println("\nHashSet");
	   HashSet<Integer> hash = new HashSet<Integer>();
	   hash.add(101);
	   hash.add(102);
	   hash.add(103);
	   hash.add(104);
	   hash.add(105);
	   System.out.println(hash);
	   
	   System.out.println("\nLinkedHashSet");
	   LinkedHashSet<Integer> ls = new LinkedHashSet<Integer>();
	   ls.add(11);
	   ls.add(12);
	   ls.add(13);
	   ls.add(14);
	   System.out.println(ls);
	}

}
