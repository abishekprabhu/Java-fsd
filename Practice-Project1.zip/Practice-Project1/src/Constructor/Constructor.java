package Constructor;

public class Constructor {
	
	int id;
	String name;
	//Default constructor
	Constructor(){
		
	}
	void display(){
		System.out.println("Default Constructor:\n"+ "id = "+id+ "\nName = "+name);		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor obj = new Constructor();
		obj.display();
		
	}

}
