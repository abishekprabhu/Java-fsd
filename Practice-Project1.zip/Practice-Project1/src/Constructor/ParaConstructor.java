package Constructor;

public class ParaConstructor {
	  int id;
	  String name;
	  //Parameterized constructor
	  ParaConstructor(int id, String name){
		  this.id = id;
		  this.name = name;
	  }
	  void display() {
		  System.out.println("\nParameterized Constructor:\n"+ "id = "+id+ "\nName = "+name);
	  }
      public static void main(String[] args) {
    	  ParaConstructor std1 = new ParaConstructor(59579, "Karthick");
    	  ParaConstructor std2 = new ParaConstructor(89798, "Sakthish");
    	  std1.display();
    	  std2.display();
}
}
