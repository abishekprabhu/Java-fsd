package InnerClassAssisted;

abstract class AnonymousInnerClass{
	public abstract void display(); 
}
public class InnerClass3 {
     public static void main(String[] args) {
	 AnonymousInnerClass in = new AnonymousInnerClass(){
		 public void display() {
			 System.err.println("Anonymous Inner Class");
		 }
	 };
	 in.display();
}
}
