package Maps;
import java.util.*;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//HashMap
		HashMap<Integer,String> h = new HashMap<Integer,String>();
		h.put(1,"one");
		h.put(2,"two");
		h.put(3, "three");

		System.out.println("The elements of Hashmap are ");
		for(Map.Entry m: h .entrySet()) {
			System.out.println(m.getKey()+" "+ m.getValue());
		}
		
		//HashTable
		Hashtable<Integer,String> ht = new Hashtable<Integer,String>();
		ht.put(4,"Ales");
		ht.put(5,"Rosy");
		ht.put(6,"Jack");
		ht.put(7,"John");
		
		System.out.println("\nThe elements of HashTable are");
		for(Map.Entry m:ht.entrySet()) {
			System.out.println(m.getKey()+" "+ m.getValue());
		}
		
		//TreeMap
		TreeMap<Integer,String> tm = new TreeMap<Integer,String>();
		tm.put(8,"Annie");
		tm.put(9,"Carlotte");
		tm.put(0,"Catie");
		
		System.out.println("\nThe elemets of TreeMap are");
		for(Map.Entry t:tm.entrySet()) {
			System.out.println(t.getKey()+" "+t.getValue());
		}
	}
}
