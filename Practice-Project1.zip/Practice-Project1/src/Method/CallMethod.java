package Method;

//call method
public class CallMethod {
	    int value = 200;
        int Operation(int value) {
        	value +=400;
        	return(value);
        }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallMethod obj = new CallMethod();
		
		System.out.println("before calling mathod value = "+ obj.value);
		obj.value = obj.Operation(700);
		System.out.println("After calling method value = "+ obj.value);
		
	}

}
