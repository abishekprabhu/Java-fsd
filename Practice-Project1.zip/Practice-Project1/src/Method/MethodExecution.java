package Method;

//method demo
public class MethodExecution {
    int Multiple(int i, int j) {
		// TODO Auto-generated constructor stub
    	int m = i*j;
    	return (m);
	}

	public static void main(String[] args) {
		MethodExecution obj = new MethodExecution();
		int ans = obj.Multiple(10,20);
		System.out.println("Multiplication Method : "+ ans);
	}
}
