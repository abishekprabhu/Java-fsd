package Method;

//Method Overloading
public class MethodOverloading {
	
	int area(int i , int j) {
		
		int a = (int) (2*3.14*i*j);
		return a;
	}
	
	int area (int i) {
		int a = (int) (2*3.14*i*i);
		return a;
	}
      public static void main(String[] args) {
    MethodOverloading obj = new MethodOverloading();
    int i = obj.area(44,22);
    int j = obj.area(58);
    System.out.println("Method Overloading with two parameters i = "+ i);
    System.out.println("Method Overloading with one parameters j = "+ j);
}
}
