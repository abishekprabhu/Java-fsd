package StringMethod;

public class stringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Method of Strings
		
		System.out.println("Methods of Strings");
		
		//Stringlength
		String str = new String("Hello World");
		System.out.println(str.length());
		
		//String subString
		String sub = new String("Welcome");
		System.out.println(sub.substring(3));
		
		//String Comparison
		String s1 = "hello";
		String s2 = "Hello";
		System.out.println(s1.compareTo(s2));
		
		//String IsEmpty
		String s3=""; //empty string
		System.out.println(s3.isEmpty());
		
		
		//toLowerCase
		String s4 = "HELLO";
		System.out.println(s4.toLowerCase());
		
		//replace
		String s5 = "World";
		System.out.println(s5.replace("r","u"));
		
		//equals
		String x = "Welcome to java";
		String y = "Welcome to python";
		System.out.println(x.equals(y));
		
		System.out.println("\nCreating String Buffer");
		//String Buffer 
		StringBuffer sb = new StringBuffer("Welcome to Java");
		sb.append("Program"); //append function
		System.out.println(sb);
		
		//insert 
		sb.insert(1,"a");
		System.out.println(sb);
		
		//replace 
		sb.replace(1, 4, "COME");
		System.out.println(sb);
		
		//delete
		sb.delete(0,1);
		System.out.println(sb);
		
		//StringBuilder
		System.out.println("\nCreating StringBuilder");
		StringBuilder s = new StringBuilder("Happy");
						
		//append
		s.append(" Learning");
		System.out.println(s.toString());
		
		//delete
		System.out.println(s.delete(0,1));
		
		//insert
		System.out.println(s.insert(1, "APPY"));
		
		//reverse
		System.out.println(s.reverse());
		
		//conversion of string to StringBuffer and StringBuilder
		
		System.out.println("\nConversion of String to StringBuffer");
		
		String st = "HELLO JAVA";
		
		StringBuffer sbr = new StringBuffer(st);
		sbr.reverse();
		System.out.println(st);
		
		StringBuilder sbu = new StringBuilder(st);
		
		sbu.append("World");
		System.out.println("\nConversion of String to StringBuilder");
		System.out.println(sbu);
		
		
	}

}
