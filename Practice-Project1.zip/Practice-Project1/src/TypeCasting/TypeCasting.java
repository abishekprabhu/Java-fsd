package TypeCasting;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		//Implicit TypeCasting
		System.out.println("Implicit Type Casting");
		
		//initialization char 
		char a = 'a';
		System.out.println("Value of a = "+ a);
	    
		//char to int 
		int b = a;
		System.out.println("Value of b = "+ b);
		
		//int to long
		long l = b;
		System.out.println("Value of l = "+ l);
		
		//long to float
		float f = l;
		System.out.println("Value of f = "+ f);
		
		//float to double
		double d = f;
		System.out.println("Value of d = "+ d);
		
		
		//Explicit TypeCasting Program
		System.out.println("\n\nExplicit TypeCasting");
		
		//Initialization of double
		double e = 65.556;
		System.out.println("Value of e = "+ e);
		
		//double to float
		float g = (float) e;
		System.out.println("Value of g = "+ g);
		
		//float to long		
		long h = (long) g; 
		System.out.println("Value of h = "+ h);
		
		//long to int 
		int i = (int) h;
		System.out.println("Value of i = "+ i);
		
		//int to char
		char c = (char) i;
		System.out.println("Value of c = "+ c);
	} 

}
