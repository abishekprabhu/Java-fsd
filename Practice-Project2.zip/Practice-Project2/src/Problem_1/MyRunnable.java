package Problem_1;

public class MyRunnable implements Runnable{
	static int count=0;
	MyRunnable(){
		//Default Constructor
	}
	//run method...
    public void run() {    	
    	while(count<=10) {
    		try {
    			System.out.println("Expl Thread: "+ ++count);
    			Thread.sleep(100);
    		}catch(Exception e) {
    			System.out.println("Exception Thread : "+ e.getMessage());
    		}
    	}    	
    }
	public static void main(String[] args) {
		System.out.println("Starting Main Thread...");
		// Thread Object		
		MyRunnable mr = new MyRunnable();
		Thread obj = new Thread(mr);
		obj.start();		
		while(count<=10) {			
    		try {
    			System.out.println("Main Thread: "+ ++count);
    			Thread.sleep(100);
    		}catch(Exception e) {
    			System.out.println("Exception Thread : "+ e.getMessage());
    		}
    	}
    	System.out.println("End of Main Thread.........");
	}

}
