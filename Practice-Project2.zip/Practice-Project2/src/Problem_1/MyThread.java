package Problem_1;

//extends Thread class
public class MyThread extends Thread {
    //run method
	public void run() {
		System.out.print("concurrent thread started running.."
				+ "");
	}
	public static void main(String[] args) {
		
		//creating a object for MyThread class
		MyThread obj = new MyThread();		
		// start method to call run method
		obj.start();

	}

}
