package Problem_3;

class Sender{
	public void send(String str) {
		System.out.println("Sending\t"+ str);
		try {
			Thread.sleep(1000);
		}catch(Exception e) {
			System.out.println("Thread interrupted");
		}
		System.out.println("\n"+ str + "Send");
	}
}

class ThreadedSend extends Thread{
	private String str;
	private Thread t ;
	Sender s;
	
	ThreadedSend(String m, Sender obj){
		str = m;
		s = obj;
	}
	
	public void run() {
		synchronized(s) {
			s.send(str);
		}
	}
}



public class SyncDemo {
      public static void main(String[] args) {
		Sender sender = new Sender(); 
		ThreadedSend t1 = new ThreadedSend(" Hi " , sender);
		ThreadedSend t2 = new ThreadedSend(" Bye ", sender);
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		}catch(Exception e){
			System.out.println("Interrupted");
		}
	}
}
