package Problem_4;

public class TryCatch {

	public static void main(String[] args) {
		// initialize array
		int arr[] = new int[3];
		
		try {
			System.out.println(arr[5]);
		}catch(Exception e) {
			System.out.println("Error : " + e);
		}
		finally {
			System.out.println("The array is of size "+ arr.length);
		}
		
 
	}

}
