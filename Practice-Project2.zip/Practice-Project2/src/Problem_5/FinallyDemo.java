package Problem_5;

public class FinallyDemo {

	public static void main(String[] args) {
		
		int a =30, b=0, c =0;
		
		try {
			c = a/b;
		}catch(Exception e) {
			System.out.println("Error: "+e.getMessage());
		}
		finally {
			System.out.println("\n\tThe result is: "+ c );
		}

	}

}
