package Problem_5;

class Parent extends Exception{
	Parent(String s){
		super(s);
	}
}
public class MyException {

	public static void main(String[] args) {
		
		try {
			throw new Parent("temp");
		}catch(Exception e) {
			System.out.println("Caught\n" + e.getMessage());
			
		}

	}

}
