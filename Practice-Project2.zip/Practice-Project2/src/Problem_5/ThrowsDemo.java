package Problem_5;

public class ThrowsDemo {
	int a = 10, b =0,c;
	void display() throws Exception {
		c = a/b;
		System.out.println(c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowsDemo t = new ThrowsDemo();
		
		
		try {
			t.display();			
		}catch(Exception e){
			System.out.println("Error: "+e.getMessage());
		}
		System.out.println("\n\tEnd of Program");

	}

}
