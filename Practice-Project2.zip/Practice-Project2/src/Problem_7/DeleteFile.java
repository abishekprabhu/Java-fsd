package Problem_7;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;

public class DeleteFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try {
			Files.delete(Paths.get("B:\\Practice-Project\\Practice-Project2\\src\\Problem_7\\textFile2.txt"));
		    
		}catch(NoSuchFileException e) {
			System.out.println("No Such file/directory exists");
		}
		catch(DirectoryNotEmptyException e) {
			System.out.println("Directory is not empty.");
		}
		catch(IOException e) {
			System.out.println("Invalid permissions.");
		}
		
		System.out.println("Deletion succesfully.");

	}

}
