package Problem_8;

public class Bicycle_3 {

   public int gear;
   public int speed;
   
   public Bicycle_3(int gear, int speed) {
	super();
	this.gear = gear;
	this.speed = speed;
}
   public int getGear() {
	return gear;
}
   public int getSpeed() {
	return speed;
}

public String toString() {
	return "Bicycle_3 [gear=" + gear + ", speed=" + speed + "]";
}
   

}
