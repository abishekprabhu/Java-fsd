package Problem_8;

public class MountainBike_3 extends Bicycle_3{
     public int seatHeight;

	public MountainBike_3(int gear, int speed, int seatHeight) {
		super(gear, speed);
		this.seatHeight = seatHeight;
	}
     
     public void setHeight(int newValue) {
    	 seatHeight = newValue;
     }
     
     public String toString() {
    	 return(super.toString()+"\nseat height is "+seatHeight);
    	 
     }
}
