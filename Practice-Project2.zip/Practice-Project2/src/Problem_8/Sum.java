package Problem_8;

public class Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sum s = new Sum();
		System.out.println(s.sum(20,30));
		System.out.println(s.sum(20,30,40));
		System.out.println(s.sum(10.5,20.5));
	}

	private double sum(double d, double e) {
		
		return d+e;
	}

	private int sum(int i, int j, int k) {
		
		return i+j+k;
	}

	private int sum(int i, int j) {
		
		return i+j;
	}

}
