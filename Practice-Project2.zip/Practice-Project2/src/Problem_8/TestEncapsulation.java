package Problem_8;

class Encapsulation{
	private String name;
	private int age;
	private int rollno;
	
	String getName() {
		return name;
	}
	
	void setName(String name) {
		this.name = name;
	}
	int getAge() {
		return age;
	}
	
	int getRoll() {
		return rollno;
	}
	
	void setAge(int age) {
		this.age = age;
	}
	void setRoll(int rollno) {
		this.rollno = rollno;
	}
}

public class TestEncapsulation {
   
	public static void main(String[] args) {
		Encapsulation e = new Encapsulation();
		e.setName("abi");
		e.setAge(23);
		e.setRoll(102020);
		
		System.out.println("Name = "+ e.getName());
		System.out.println("Age = "+ e.getAge());
		System.out.println("Rollno = "+ e.getRoll());
		}

}
