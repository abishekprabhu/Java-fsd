package Problem_8;

public class TestInheritance_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        MountainBike_3 m = new MountainBike_3(3,100,25);
	   System.out.println(m.toString()); 
	}

}
