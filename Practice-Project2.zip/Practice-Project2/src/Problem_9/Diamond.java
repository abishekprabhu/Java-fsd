package Problem_9;

interface First{
	default void display() {
		System.out.println("First Interface");
	}
}

interface Second{
	default void display() {
		System.out.println("Second Interface");
		
	}
}

public class Diamond implements First, Second {
    public void display() {
    	First.super.display();
    	Second.super.display();
    }
	public static void main(String[] args) {
		Diamond d = new Diamond();
		d.display();

	}

}
