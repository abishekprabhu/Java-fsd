package Problem_2;

public class Main {

	public static void main(String[] args) {
		UnsortedArray obj = new UnsortedArray();
		int arr[] = {12,3,5,7,4,19,26};
		int size = arr.length;
		int k = 4;
		System.out.println("K'th Smallest element is "+ obj.KthSmallest(arr,0,size-1,k));

	}
}
class UnsortedArray{
	public int KthSmallest(int[] arr, int l, int r, int k) {
		
		if(k>0 && k<=r-l+1)
		{
			int pos = randomPartition(arr,l,r);
			if(pos-l == k-1)
				return arr[pos];
			if(pos-l > k-1)
				return KthSmallest(arr,l,pos-1,k);
			return KthSmallest(arr,pos+1,r,k-pos+l-1);
		}
		
		return Integer.MAX_VALUE;
	}

	private int randomPartition(int[] arr, int l, int r) {
		int n = r-l+1;
		int pivot = (int)(Math.random())* (n-1);
		swap(arr, l+pivot,r);
		return partition(arr,l,r);
	}

	private void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;		
	}

	private int partition(int[] arr, int l, int r) {
		int x=arr[r], i = l;
		for(int j=l; j <=r-1;j++) {
			if(arr[j]<=x) {
				swap(arr,i,j);
				i++;
			}
		}
		swap(arr,i,r);
		return i;
		
	}

}
