package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.AadharCard;



public interface AadharCardRepo extends JpaRepository<AadharCard, Long>{

}