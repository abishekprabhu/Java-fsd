import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  username:string="";
  password:string="";
  msg:string = "";

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  LoginCheck(frm: any) {
    if (frm.valid) {
      const storedData = localStorage.getItem('registrationData');
  
      if (storedData) {
        const registrationData = JSON.parse(storedData);
  
        if (this.username === registrationData.email && this.password === registrationData.password) {
          // Login successful
          // this.router.navigate(['/welcome']);
          this.msg = "Login Successfully";
        } else {
          this.msg = "Incorrect..!<br />Please check your email and password";
        }
      } else {
        this.msg = "No registration data found";
      }
    } else {
      this.msg = "Invalid Form";
    }
  }
  
}
