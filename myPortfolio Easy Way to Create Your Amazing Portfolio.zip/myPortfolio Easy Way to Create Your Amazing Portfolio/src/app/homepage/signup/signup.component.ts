import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent  implements OnInit {

  constructor(private builder:FormBuilder) { }

  ngOnInit(): void {
  }
  result:any;
  msg:string="";

  regForm = this.builder.group({
    personname: this.builder.control('', Validators.required),
    phonenumber: this.builder.control('', Validators.required),
    email:this.builder.control('', Validators.required),
    password:this.builder.control('', Validators.required)
  });

printDetails() {
  if (this.regForm.valid) {
    const registrationData = {
      personname: this.regForm.value.personname,
      phonenumber: this.regForm.value.phonenumber,
      email: this.regForm.value.email,
      password: this.regForm.value.password
    };

    // Store the registration data in localStorage
    localStorage.setItem('registrationData', JSON.stringify(registrationData));

    this.msg = "Registration successful....!<br /> " + JSON.stringify(registrationData);
  } else {
    this.msg = "Invalid Form";
  }
}

}