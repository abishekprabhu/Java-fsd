import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  email!: string;
  password!: string;

  signup() {
    if (this.validateEmail(this.email) && this.validatePassword(this.password)) {
      // Send signup request to the server or perform relevant actions
      console.log('Signup successful');
    } else {
      console.log('Invalid email or password');
    }
  }

  private validateEmail(email: string): boolean {
    // Simple email validation using regex pattern
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }

  private validatePassword(password: string): boolean {
    // Password validation - minimum 8 characters
    return password.length >= 8;
  }
}
